<script>
	import Controller from "./Controller.svelte";
	let name = 'world';
</script>

<h1>Plug in an XBOX controller, and play around!</h1>
<Controller />
<h2>Experimenting with the <a href="https://developer.mozilla.org/en-US/docs/Web/API/Gamepad_API/Using_the_Gamepad_API">GamePadApi</a> with Svelte</h2>

<style>
	
	:global(*) {
		box-sizing: border-box;
	}
	
	:global(body,html) {
		width: 100%;
		height: 100%;
		margin: 0;
		padding: 0;
		display: flex;
		flex-direction: column;
		justify-content: center;
		align-items: center;
	}
	
	h1 {
		margin: 3vw;
		font-size: 3vw;
	}
	
	h2 {
		margin: 2.4vw;
		font-size: 2.4vw;
	}
	
	a {
		color: #17a1cc;
	}
	
</style>