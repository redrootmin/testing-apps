# CSS Toggle Radio Buttons

A Pen created on CodePen.io. Original URL: [https://codepen.io/ericponto/pen/Agmaoy](https://codepen.io/ericponto/pen/Agmaoy).

CSS only toggle buttons using radios and the :checked pseudo class.