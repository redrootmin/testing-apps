# CSS Switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/cl0udc0ntr0l/pen/njQQbw](https://codepen.io/cl0udc0ntr0l/pen/njQQbw).

Toggle switch with css animation.