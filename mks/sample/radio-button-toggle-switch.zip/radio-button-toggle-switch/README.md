# Radio button toggle switch

A Pen created on CodePen.io. Original URL: [https://codepen.io/JiveDig/pen/jbdJXR](https://codepen.io/JiveDig/pen/jbdJXR).

Display standard html radio buttons as toggle buttons. Full blog post: <a href="https://thestizmedia.com/radio-buttons-as-toggle-buttons-with-css/">https://thestizmedia.com/radio-buttons-as-toggle-buttons-with-css/</a>