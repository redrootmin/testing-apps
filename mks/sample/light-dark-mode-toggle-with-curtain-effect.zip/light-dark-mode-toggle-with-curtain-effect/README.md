# Light/Dark Mode Toggle With Curtain Effect

A Pen created on CodePen.io. Original URL: [https://codepen.io/jkantner/pen/LYprqQM](https://codepen.io/jkantner/pen/LYprqQM).

A light and dark switch where the handle bounces into place while a curtain inverts the scheme. Based on [this Dribbble shot](https://dribbble.com/shots/6041286-Switcher-LI).