# Table morphs into graph... without a lot of weirdness

A Pen created on CodePen.io. Original URL: [https://codepen.io/kumbi/pen/rpjGyy](https://codepen.io/kumbi/pen/rpjGyy).

