# XMB

[Live demo](https://tsbehlman.github.io/xmb/index.html)

A WebGL visualization inspired by [RetroArch](http://github.com/libretro/RetroArch)'s default animated wallpaper, which is inspired by the default wallpapers featured in [Sony's XMB](https://en.wikipedia.org/wiki/XrossMediaBar).
