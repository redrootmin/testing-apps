# ps4-ui

### un concepto de interface de una consola ps3

un reto que me plateé, para practicar mis tempranas habilidades de frontend  😎

* menu desplegable
* multi-menu


