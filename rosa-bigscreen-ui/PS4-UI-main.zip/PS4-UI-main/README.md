# PS4-UI
Interface de usuário do ps4
## Informações importantes
Este projeto foi feito a fins didáticos. O objetivo foi tentar recriar a 
Interface de usuário do PS4. Periodicamente recebendo atualizações.
