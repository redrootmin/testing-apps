//Pseudo-Json
let games = [
    {game: "The last of US",img: "https://gmedia.playstation.com/is/image/SIEPDC/the-last-of-us-remastered-pack-01-ps4-en-23jul20?$native$"},
    {game: "Dark Souls",img: "https://image.api.playstation.com/gs2-sec/appkgo/prod/CUSA03365_00/2/i_1bf8d3317ff642710196c85c859320f0a9345e3c65a9132d588239fab877d81a/i/icon0.png"},
    {game: "Cuphead",img: "https://image.api.playstation.com/gs2-sec/appkgo/prod/CUSA20469_00/1/i_3fa25ceb0c4d77fb214dce8cd1ad03d339d78d5db47c4f2511260595cbb38d00/i/icon0.png"},
    {game: "Spider Man",img: "https://image.api.playstation.com/vulcan/img/rnd/202011/0714/YxnYgr7GHM0JVQRSrnOK35yr.png"},
    {game: "The Witcher 3: Wild Hunt",img: "https://image.api.playstation.com/vulcan/img/rnd/202009/2913/TQKAd8U6hnIFQIIcz6qnFh8C.png"},
    {game: "RESIDENT EVIL 7",img: "https://image.api.playstation.com/cdn/UP0102/CUSA03962_00/nAGbvBYhrj8Kf8Rv4zbVmbqsWZxYqb7O.png"},
    {game: "Far Cry 4",img: "https://image.api.playstation.com/cdn/UP0001/CUSA00496_00/HmQCYexmTfdsfDQnf3L6vux2ulWX75Zt.png?w=440"},
]